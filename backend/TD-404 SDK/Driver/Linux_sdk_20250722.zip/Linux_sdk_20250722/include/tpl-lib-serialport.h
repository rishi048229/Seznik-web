#ifndef TPL_LIB_SERIALPORT_H
#define TPL_LIB_SERIALPORT_H

#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>

/**
 * @brief 串口配置结构体
 */
typedef struct {
    const char *port;       // 串口设备路径 (e.g. "/dev/ttyUSB0")
    int baud_rate;          // 波特率 (e.g. 9600, 115200)
    int data_bits;          // 数据位 (5,6,7,8)
    char parity;            // 校验位 (N:无校验, E:偶校验, O:奇校验)
    int stop_bits;          // 停止位 (1,2)
    int flow_control;       // 流控 (0:无, 1:硬件, 2:软件)
    int timeout_ms;         // 读写超时(毫秒)
} SerialConfig;

// 常用波特率定义
#define BAUDRATE_9600     9600
#define BAUDRATE_19200   19200
#define BAUDRATE_38400   38400
#define BAUDRATE_57600   57600
#define BAUDRATE_115200 115200

// 默认串口配置
#define DEFAULT_SERIAL_PORT    "/dev/ttyUSB0"
#define DEFAULT_BAUD_RATE      BAUDRATE_115200
#define DEFAULT_DATA_BITS      8
#define DEFAULT_PARITY         'N'
#define DEFAULT_STOP_BITS      1
#define DEFAULT_FLOW_CONTROL   0
#define DEFAULT_TIMEOUT_MS     1000

/**
 * @brief 打开并配置串口
 * 
 * @param config 串口配置参数
 * @return 成功返回文件描述符，失败返回-1
 */
int serial_open(SerialConfig *config);

/**
 * @brief 发送数据到串口
 * 
 * @param fd 串口文件描述符
 * @param data 要发送的数据缓冲区
 * @param len 数据长度
 * @return 成功返回发送的字节数，失败返回-1
 */
ssize_t serial_send(int fd, const uint8_t *data, size_t len);

/**
 * @brief 从串口接收数据
 * 
 * @param fd 串口文件描述符
 * @param buffer 接收数据的缓冲区
 * @param buffer_size 缓冲区大小
 * @param timeout_ms 超时时间(毫秒)，-1表示阻塞等待
 * @return 成功返回接收的字节数，失败返回-1，超时返回0
 */
ssize_t serial_receive(int fd, uint8_t *buffer, size_t buffer_size, int timeout_ms);

/**
 * @brief 关闭串口
 * 
 * @param fd 要关闭的串口文件描述符
 */
void serial_close(int fd);

#endif // TPL_LIB_SERIALPORT_H
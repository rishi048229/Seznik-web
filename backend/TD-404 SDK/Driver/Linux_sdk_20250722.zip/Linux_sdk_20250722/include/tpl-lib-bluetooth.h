#ifndef TPL_LIB_BLUETOOTH_H
#define TPL_LIB_BLUETOOTH_H

#include <bluetooth/bluetooth.h>
#include <bluetooth/rfcomm.h>
#include <stdint.h>

// 默认蓝牙设备地址
#define DEFAULT_BT_ADDR "DC:0D:30:50:09:1D"
// 默认RFCOMM通道
#define DEFAULT_BT_CHANNEL 1

/**
 * @brief 连接到指定的蓝牙设备
 * @param dest 目标蓝牙设备地址 (格式 "XX:XX:XX:XX:XX:XX")
 * @param channel RFCOMM通道号
 * @return 成功返回socket描述符，失败返回-1
 */
int bt_connect(const char *dest, uint8_t channel);
/**
 * @brief 发送数据到已连接的蓝牙设备
 * @param sock 已建立的socket连接
 * @param data 要发送的数据缓冲区
 * @param len 数据长度
 * @return 成功返回发送的字节数，失败返回-1
 */
int bt_send_data(int sock, const uint8_t *data, size_t len);

/**
 * @brief 断开蓝牙连接
 * @param sock 要关闭的socket描述符
 */
void bt_disconnect(int sock);

#endif // TPL_LIB_BLUETOOTH_H
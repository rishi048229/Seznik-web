#ifndef TPL_LIB_NET_H
#define TPL_LIB_NET_H

#include <stdint.h>
#include <stddef.h>
#include <sys/types.h>

/**
 * @brief 连接到指定的TCP服务器
 * 
 * @param host 服务器主机名或IP地址
 * @param port 服务器端口号
 * @return 成功返回socket描述符，失败返回-1
 */
int tcp_connect(const char *host, uint16_t port);

/**
 * @brief 发送数据到已连接的TCP服务器
 * @param sock 已建立的socket连接
 * @param data 要发送的数据缓冲区
 * @param len 数据长度
 * @return 成功返回发送的字节数，失败返回-1
 */
ssize_t tcp_send_data(int sock, const uint8_t *data, size_t len);

/**
 * @brief 接收TCP服务器发送的数据
 * 
 * @param sock 已建立的socket连接
 * @param buffer 接收数据的缓冲区
 * @param buffer_size 缓冲区大小
 * @param timeout_sec 超时时间（秒），0表示阻塞等待
 * @return 成功返回接收的字节数，失败返回-1，超时返回0
 */
ssize_t tcp_receive_data(int sock, uint8_t *buffer, size_t buffer_size, int timeout_sec);

/**
 * @brief 断开TCP连接
 * 
 * @param sock 要关闭的socket描述符
 */
void tcp_disconnect(int sock);

#endif // TPL_LIB_NET_H
#ifndef TPL_LIB_USB_H
#define TPL_LIB_USB_H

#include <libusb-1.0/libusb.h>

int usb_device_init(libusb_context **ctx, libusb_device_handle **handle, int index);
int usb_device_write(libusb_device_handle *handle, unsigned char *data, int length);
int usb_device_read(libusb_device_handle *handle, unsigned char *data, int max_length, int *actual_length);
void usb_device_cleanup(libusb_context *ctx, libusb_device_handle *handle);
int usb_get_endpoints(libusb_device *dev, int desired_interface_index,
                      int *interface_number, unsigned char *ep_in, unsigned char *ep_out);

#endif // TPL_LIB_USB_H

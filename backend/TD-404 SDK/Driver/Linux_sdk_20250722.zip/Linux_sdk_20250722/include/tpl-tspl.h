#ifndef TPL_TSPL_H
#define TPL_TSPL_H

#include <stddef.h>
#include <stdint.h>

// 命令格式化函数
int TSPL_Text(char *outBuf, size_t bufSize, int x, int y, const char *font,
              const char *content, int rotation, int x_mul, int y_mul, int alignment);

int TSPL_BarCode(char *outBuf, size_t bufSize, int x, int y, int type,
                 const char *content, int height, int showText, int rotation,
                 int narrow, int wide);

int TSPL_QRCode(char *outBuf, size_t bufSize, int x, int y, int width, int eccLevel,
                int mode, int rotation, const char *data);

int TSPL_Bitmap(char *outBuf, size_t bufSize, int x, int y,
                int width, int height, int mode);

int TSPL_CLS(char *outBuf, size_t bufSize);

int TSPL_Print(char *outBuf, size_t bufSize, int copies);

// 生成一个白底黑圆的位图，返回填充的字节数
int generate_circle_bitmap(uint8_t *buf, int width_px, int height_px);

typedef struct {
    const char *codeString;
} CodeType;

typedef struct {
    const char *level;
} ErrLevel;

typedef struct {
    const char *mode;
} QrMode;

// 支持的条码类型、二维码纠错等级、模式
extern const CodeType codeTypeArr[];
extern const int codeTypeArrSize;

extern const ErrLevel errLevelArr[];
extern const int errLevelArrSize;

extern const QrMode qrCodemode[];
extern const int qrCodemodeSize;

#endif // TPL_TSPL_H

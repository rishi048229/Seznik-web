#include "tpl-lib-serialport.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char **argv) {
    int serial_fd = -1;
    
    // 配置串口参数
    SerialConfig config = {
        .port = DEFAULT_SERIAL_PORT,
        .baud_rate = DEFAULT_BAUD_RATE,
        .data_bits = DEFAULT_DATA_BITS,
        .parity = DEFAULT_PARITY,
        .stop_bits = DEFAULT_STOP_BITS,
        .flow_control = DEFAULT_FLOW_CONTROL,
        .timeout_ms = DEFAULT_TIMEOUT_MS
    };
    
    // 允许通过命令行参数指定串口设备
    if (argc > 1) {
        config.port = argv[1];
    }
    
    fprintf(stderr, "串口设备: %s\n", config.port);
    fprintf(stderr, "波特率: %d\n", config.baud_rate);
    fprintf(stderr, "数据位: %d\n", config.data_bits);
    fprintf(stderr, "校验位: %c\n", config.parity);
    fprintf(stderr, "停止位: %d\n", config.stop_bits);
    fprintf(stderr, "流控: %s\n", 
        config.flow_control == 0 ? "无" : 
        config.flow_control == 1 ? "硬件" : "软件");
    fprintf(stderr, "超时: %d ms\n", config.timeout_ms);

    // 1. 打开并配置串口
    serial_fd = serial_open(&config);
    if (serial_fd < 0) {
        fprintf(stderr, "无法打开串口设备\n");
        return 1;
    }

        char buf[256], cmd[256];
        uint8_t image_data[2048];
        int width_px = 128, height_px = 128;
        int width_bytes = (width_px + 7) / 8;

        int image_len = generate_circle_bitmap(image_data, width_px, height_px);
        int len, cmd_len;


        // 清屏
        len = TSPL_CLS(buf, sizeof(buf));
        serial_send(serial_fd, (const uint8_t *)buf, len);
        usleep(100 * 1000);

        // 发送图像命令头
        cmd_len = TSPL_Bitmap(cmd, sizeof(cmd), 50, 100, width_bytes, height_px, 0);
        serial_send(serial_fd, (const uint8_t *)cmd, cmd_len);

        // 发送图像数据
        serial_send(serial_fd, image_data, image_len);
        usleep(100 * 1000);

        // 文字
        len = TSPL_Text(buf, sizeof(buf), 300, 200, "TSS24.BF2", "Hello USB", 0, 1, 1, 0);
        serial_send(serial_fd, (const uint8_t *)buf, len);
        usleep(50 * 1000);

        // 二维码
        len = TSPL_QRCode(buf, sizeof(buf), 250, 300, 6, 2, 1, 0, "https://baidu.com");
        serial_send(serial_fd, (const uint8_t *)buf, len);
        usleep(50 * 1000);

        // 条码
        len = TSPL_BarCode(buf, sizeof(buf), 250, 500, 0, "123456789", 100, 1, 0, 2, 2);
        serial_send(serial_fd, (const uint8_t *)buf, len);
        usleep(50 * 1000);

        len = TSPL_Print(buf, sizeof(buf), 1);
        serial_send(serial_fd, (const uint8_t *)buf, len);
        usleep(100 * 1000);

        // 关闭串口
        serial_close(serial_fd);

        fprintf(stderr, "程序结束。\n");
        return 0;
    }

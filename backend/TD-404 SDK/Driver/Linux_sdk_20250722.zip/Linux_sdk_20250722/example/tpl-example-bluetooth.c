#include "tpl-lib-bluetooth.h"
#include "tpl-tspl.h"
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <string.h>

int main(int argc, char **argv) {
    int sock = -1;
    const char *bt_addr = DEFAULT_BT_ADDR;
    uint8_t bt_channel = DEFAULT_BT_CHANNEL;

    if (argc > 1) bt_addr = argv[1];
    if (argc > 2) bt_channel = (uint8_t)atoi(argv[2]);

    fprintf(stderr, "目标设备: %s\n", bt_addr);
    fprintf(stderr, "通道号: %d\n", bt_channel);

    sock = bt_connect(bt_addr, bt_channel);
    if (sock < 0) {
        fprintf(stderr, "无法连接到蓝牙设备\n");
        return 1;
    }

    char buf[256], cmd[256];
    uint8_t image_data[2048];
    int width_px = 128, height_px = 128;
    int width_bytes = (width_px + 7) / 8;

    int image_len = generate_circle_bitmap(image_data, width_px, height_px);
    if (image_len <= 0) {
        fprintf(stderr, "生成图像失败\n");
        goto cleanup;
    }

    int len, cmd_len;

      // 清屏
    len = TSPL_CLS(buf, sizeof(buf));
    if (bt_send_data(sock, (uint8_t *)buf, len) < 0) goto cleanup;
    usleep(100 * 1000);

    // 发送图像命令头
    cmd_len = TSPL_Bitmap(cmd, sizeof(cmd), 50, 100, width_bytes, height_px, 0);
    if (bt_send_data(sock, (uint8_t *)cmd, cmd_len) < 0) goto cleanup;

    // 发送图像数据
    if (bt_send_data(sock, image_data, image_len) < 0) goto cleanup;
    usleep(100 * 1000);

    // 文字
    len = TSPL_Text(buf, sizeof(buf), 300, 200, "TSS24.BF2", "Hello", 0, 1, 1, 0);
    if (bt_send_data(sock, (uint8_t *)buf, len) < 0) goto cleanup;
    usleep(50 * 1000);

    // 条码
    len = TSPL_BarCode(buf, sizeof(buf), 250, 300, 0, "123456789", 100, 1, 0, 2, 2);
    if (bt_send_data(sock, (uint8_t *)buf, len) < 0) goto cleanup;
    usleep(50 * 1000);

    // 二维码
    len = TSPL_QRCode(buf, sizeof(buf), 250, 500, 6, 2, 1, 0, "https://baidu.com");
    if (bt_send_data(sock, (uint8_t *)buf, len) < 0) goto cleanup;
    usleep(50 * 1000);

    // 打印
    len = TSPL_Print(buf, sizeof(buf), 1);
    if (bt_send_data(sock, (uint8_t *)buf, len) < 0) goto cleanup;
    usleep(100 * 1000);

cleanup:
    bt_disconnect(sock);
    fprintf(stderr, "程序结束。\n");
    return 0;
}

#include "tpl-lib-usb.h"
#include "tpl-tspl.h"
#include <stdio.h>
#include <string.h>
#include <unistd.h>

int main() {
    libusb_context *ctx = NULL;
    libusb_device_handle *handle = NULL;

    fprintf(stderr, "USB设备通信示例\n");

    // 1. 初始化USB设备
    int r = usb_device_init(&ctx, &handle,0);
    if (r < 0) {
        fprintf(stderr, "USB设备初始化失败\n");
        return 1;
    }

        char buf[256], cmd[256];
        uint8_t image_data[2048];
        int width_px = 128, height_px = 128;
        int width_bytes = (width_px + 7) / 8;

        int image_len = generate_circle_bitmap(image_data, width_px, height_px);

        int len;


        // 清屏
        len = TSPL_CLS(buf, sizeof(buf));
        usb_device_write(handle, (const uint8_t *)buf, len);
        usleep(100 * 1000);

        // 发送图像
        int cmd_len = TSPL_Bitmap(cmd, sizeof(cmd), 50, 100, width_bytes, height_px, 0);
        usb_device_write(handle, (uint8_t *)cmd, cmd_len);
        usb_device_write(handle, image_data, image_len);
        usleep(1000 * 1000);


        // 文字
        len = TSPL_Text(buf, sizeof(buf), 300, 200, "TSS24.BF2", "Hello", 0, 1, 1, 0);
        usb_device_write(handle, (const uint8_t *)buf, len);
        usleep(50 * 1000);

        // 二维码
        len = TSPL_QRCode(buf, sizeof(buf), 250, 300, 6, 2, 1, 0, "https://baidu.com");
        usb_device_write(handle, (const uint8_t *)buf, len);
        usleep(50 * 1000);

        // 条码
        len = TSPL_BarCode(buf, sizeof(buf), 250, 500, 0, "123456789", 100, 1, 0, 2, 2);
        usb_device_write(handle, (const uint8_t *)buf, len);
        usleep(50 * 1000);

        len = TSPL_Print(buf, sizeof(buf), 1);
        usb_device_write(handle, (const uint8_t *)buf, len);
        usleep(100 * 1000);
    
    usb_device_cleanup(ctx, handle);

    fprintf(stderr, "程序结束。\n");
    return 0;
}

#include "tpl-lib-net.h"
#include "tpl-tspl.h"
#include <stdio.h>
#include <unistd.h>
#include <string.h>

#define DEFAULT_HOST "169.1.220.1"
#define DEFAULT_PORT 9100

int main(int argc, char **argv) {
    int sock = -1;
    const char *host = DEFAULT_HOST;
    uint16_t port = DEFAULT_PORT;
    
    // 允许通过命令行参数指定主机和端口
    if (argc > 1) {
        host = argv[1];
    }
    if (argc > 2) {
        port = (uint16_t)atoi(argv[2]);
    }
    
    fprintf(stderr, "TCP客户端 v1.0\n");
    fprintf(stderr, "目标服务器: %s\n", host);
    fprintf(stderr, "端口号: %u\n", port);

    // 1. 连接到TCP服务器
    sock = tcp_connect(host, port);
    if (sock < 0) {
        fprintf(stderr, "无法连接到服务器\n");
        return 1;
    }


        char buf[256], cmd[256];
        uint8_t image_data[2048];
        int width_px = 128, height_px = 128;
        int width_bytes = (width_px + 7) / 8;

        int image_len = generate_circle_bitmap(image_data, width_px, height_px);
        int len, cmd_len;


        // 清屏
        len = TSPL_CLS(buf, sizeof(buf));
        if (tcp_send_data(sock, (const uint8_t *)buf, len) < 0) goto cleanup;
        usleep(100 * 1000);

        // 发送图像命令头
        cmd_len = TSPL_Bitmap(cmd, sizeof(cmd), 50, 100, width_bytes, height_px, 0);
        if (tcp_send_data(sock, (const uint8_t *)cmd, cmd_len) < 0) goto cleanup;

        // 发送图像数据
        if (tcp_send_data(sock, image_data, image_len) < 0) goto cleanup;
        usleep(100 * 1000);

        // 文字
        len = TSPL_Text(buf, sizeof(buf), 300, 200, "TSS24.BF2", "Hello", 0, 1, 1, 0);
        if (tcp_send_data(sock, (const uint8_t *)buf, len) < 0) goto cleanup;
        usleep(50 * 1000);

        // 二维码
        len = TSPL_QRCode(buf, sizeof(buf), 250, 300, 6, 2, 1, 0, "https://baidu.com");
        if (tcp_send_data(sock, (const uint8_t *)buf, len) < 0) goto cleanup;
        usleep(50 * 1000);

        // 条码
        len = TSPL_BarCode(buf, sizeof(buf), 250, 500, 0, "123456789", 100, 1, 0, 2, 2);
        if (tcp_send_data(sock, (const uint8_t *)buf, len) < 0) goto cleanup;
        usleep(50 * 1000);

        len = TSPL_Print(buf, sizeof(buf), 1);
        if (tcp_send_data(sock, (const uint8_t *)buf, len) < 0) goto cleanup;
        usleep(100 * 1000);

// 等待响应（示例，非必须）
/*uint8_t buffer[4096];
ssize_t total_received = 0, bytes_received;
fprintf(stderr, "等待响应...\n");
do {
    bytes_received = tcp_receive_data(sock, buffer + total_received,
                                     sizeof(buffer) - total_received, 5);
    if (bytes_received > 0) {
        total_received += bytes_received;
    }
} while (bytes_received > 0);

if (total_received > 0) {
    fprintf(stderr, "\n===== 完整响应 (%zd 字节) =====\n", total_received);
    size_t print_len = total_received < 512 ? total_received : 512;
    for (size_t i = 0; i < print_len; i++) {
        putchar(buffer[i]);
    }
    fprintf(stderr, "\n...\n");
} else if (total_received == 0) {
    fprintf(stderr, "未收到响应\n");
}*/

cleanup:
tcp_disconnect(sock);
fprintf(stderr, "程序结束。\n");
return 0;
}